package org.name1.package1;

public class Class1
{

	public static int g = 5;
	
	public int f1(int a, int b)
	{
		int x = a + b;
		System.out.println("x = " + x);
		return x;
	}
	
	public int f2()
	{
		System.out.println("msg f2");
		return 5;
	}
	
	public void f3()
	{
		System.out.println("msg f3");
	}
	
	public static void main(String[] args)
	{
		Class1 t1 = new Class1();
		System.out.println(t1.f1(5, 10));
		System.out.println();
		System.out.println(t1.f2());
	}

}
