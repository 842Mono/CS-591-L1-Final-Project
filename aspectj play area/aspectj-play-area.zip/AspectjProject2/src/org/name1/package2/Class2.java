package org.name1.package2;

public class Class2
{

	public int f1()
	{
		System.out.println("f1");
		return 10;
	}
	
	public int f2(int x, int y)
	{
		return x * y;
	}
	
	public static void main(String[] args)
	{
		Class2 c2 = new Class2();
		System.out.println(c2.f1());
		System.out.println();
		System.out.println(c2.f2(2, 3));
	}

}
